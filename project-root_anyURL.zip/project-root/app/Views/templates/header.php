<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
</head>
<body>
<h3><a href="/pages">Home</a> | 
<a href="/profile">Profile</a> | 
<a href="/about">About</a></h3>
